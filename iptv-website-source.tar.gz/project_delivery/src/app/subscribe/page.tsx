import Link from "next/link";
import SubscriptionForm from "@/components/SubscriptionForm";

export default function Subscribe() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Start Your Free Trial Today
            </h1>
            <p className="text-xl text-gray-300 mb-6">
              Experience the best IPTV service with access to 20,000+ channels and 60,000+ on-demand titles. No credit card required.
            </p>
          </div>
        </div>
      </section>

      {/* Subscription Form Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-3xl font-bold mb-6">Why Choose StreamFlex IPTV?</h2>
                
                <div className="space-y-6">
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-xl font-medium text-gray-900">Extensive Content Library</h3>
                      <p className="mt-2 text-gray-600">
                        Access over 20,000 live channels and 60,000+ on-demand titles from around the world.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-xl font-medium text-gray-900">Time-Shifted TV</h3>
                      <p className="mt-2 text-gray-600">
                        Never miss your favorite shows with our time-shifting technology that lets you watch content up to 24 hours after it aired.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                        </svg>
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-xl font-medium text-gray-900">Multi-Device Support</h3>
                      <p className="mt-2 text-gray-600">
                        Watch on your Smart TV, smartphone, tablet, computer, or streaming device with our easy-to-use apps.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex">
                    <div className="flex-shrink-0">
                      <div className="flex items-center justify-center h-12 w-12 rounded-md bg-blue-600 text-white">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                      </div>
                    </div>
                    <div className="ml-4">
                      <h3 className="text-xl font-medium text-gray-900">High-Quality Streaming</h3>
                      <p className="mt-2 text-gray-600">
                        Enjoy crystal-clear HD and Ultra HD streaming with our advanced anti-buffering technology and 99.9% uptime guarantee.
                      </p>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 border-t border-gray-200 pt-8">
                  <h3 className="text-xl font-medium text-gray-900 mb-4">What Our Customers Say</h3>
                  
                  <div className="bg-white p-6 rounded-lg shadow-sm">
                    <div className="flex items-center mb-4">
                      <div className="text-yellow-400 flex">
                        {[...Array(5)].map((_, i) => (
                          <svg key={i} className="h-5 w-5 fill-current" viewBox="0 0 20 20">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                          </svg>
                        ))}
                      </div>
                    </div>
                    <p className="text-gray-600 mb-4">
                      "StreamFlex IPTV has completely changed how I watch TV. The channel selection is amazing, and I love being able to watch on all my devices. The quality is excellent, even during peak hours."
                    </p>
                    <div className="font-semibold">Michael R.</div>
                    <div className="text-gray-500 text-sm">Subscribed for 1 year</div>
                  </div>
                </div>
              </div>
              
              <div>
                <SubscriptionForm />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Methods */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-6">Secure Payment Methods</h2>
            <div className="flex flex-wrap justify-center items-center gap-8">
              <div className="w-16 h-10 bg-gray-200 rounded flex items-center justify-center">
                <span className="text-gray-500 text-xs">Visa</span>
              </div>
              <div className="w-16 h-10 bg-gray-200 rounded flex items-center justify-center">
                <span className="text-gray-500 text-xs">MasterCard</span>
              </div>
              <div className="w-16 h-10 bg-gray-200 rounded flex items-center justify-center">
                <span className="text-gray-500 text-xs">PayPal</span>
              </div>
              <div className="w-16 h-10 bg-gray-200 rounded flex items-center justify-center">
                <span className="text-gray-500 text-xs">Apple Pay</span>
              </div>
              <div className="w-16 h-10 bg-gray-200 rounded flex items-center justify-center">
                <span className="text-gray-500 text-xs">Bitcoin</span>
              </div>
            </div>
            <p className="mt-6 text-gray-600 text-sm">
              All transactions are secure and encrypted. Your payment information is never stored on our servers.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-16 bg-gray-100">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Find answers to common questions about our free trial and subscription process.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto">
            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-2">How does the free trial work?</h3>
              <p className="text-gray-600">
                Our free trial gives you full access to all features for 3 days. No credit card is required to start the trial. You'll receive login details immediately after signing up.
              </p>
            </div>
            
            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-2">What happens after the trial period?</h3>
              <p className="text-gray-600">
                After your trial ends, you can choose to subscribe to one of our plans. If you decide not to subscribe, your account will simply expire with no charges.
              </p>
            </div>
            
            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-2">Can I cancel my subscription?</h3>
              <p className="text-gray-600">
                Yes, you can cancel your subscription at any time from your account dashboard. There are no cancellation fees or hidden charges.
              </p>
            </div>
            
            <div className="mb-6">
              <h3 className="text-xl font-semibold mb-2">How do I access the service after subscribing?</h3>
              <p className="text-gray-600">
                After subscribing, you'll receive login credentials via email. You can use these credentials to access our service on any supported device through our apps or web player.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
