import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function FAQ() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="bg-gray-900 text-white py-16">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">
              Frequently Asked Questions
            </h1>
            <p className="text-xl text-gray-300 mb-6">
              Find answers to the most common questions about StreamFlex IPTV service.
            </p>
          </div>
        </div>
      </section>

      {/* FAQ Categories */}
      <section className="py-8 bg-white border-b">
        <div className="container mx-auto px-4">
          <div className="flex flex-wrap justify-center gap-4">
            <a href="#general" className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full hover:bg-blue-200 transition-colors">
              General Questions
            </a>
            <a href="#technical" className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full hover:bg-blue-200 transition-colors">
              Technical Support
            </a>
            <a href="#subscription" className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full hover:bg-blue-200 transition-colors">
              Subscription & Billing
            </a>
            <a href="#content" className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full hover:bg-blue-200 transition-colors">
              Content & Channels
            </a>
            <a href="#devices" className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full hover:bg-blue-200 transition-colors">
              Devices & Compatibility
            </a>
          </div>
        </div>
      </section>

      {/* General Questions */}
      <section id="general" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">General Questions</h2>
          
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">What is IPTV?</h3>
              <p className="text-gray-600">
                IPTV (Internet Protocol Television) delivers television content over Internet Protocol networks. Unlike traditional TV that relies on satellite or cable, IPTV uses your internet connection to stream content to your devices. This allows for more flexibility, features like on-demand viewing, and access across multiple devices.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">What makes StreamFlex IPTV different from other services?</h3>
              <p className="text-gray-600">
                StreamFlex IPTV stands out with our extensive library of 20,000+ live channels and 60,000+ on-demand titles, superior HD and 4K streaming quality, reliable 99.9% uptime, multi-device support, and exceptional customer service. We also offer advanced features like time-shifted viewing, cloud DVR, and personalized recommendations that many competitors don't provide.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Is IPTV legal?</h3>
              <p className="text-gray-600">
                Yes, StreamFlex IPTV is a legal service that licenses content from providers. We comply with all relevant regulations and copyright laws to ensure our customers receive legitimate, high-quality content. We maintain proper licensing agreements for all the content available through our service.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Do I need special equipment to use StreamFlex IPTV?</h3>
              <p className="text-gray-600">
                No special equipment is needed. StreamFlex IPTV works on devices you already own, including Smart TVs, streaming devices (Roku, Fire TV, Apple TV), smartphones, tablets, and computers. You simply need a stable internet connection and our app or web player to start watching.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Technical Support */}
      <section id="technical" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Technical Support</h2>
          
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">What internet speed do I need?</h3>
              <p className="text-gray-600">
                We recommend a minimum internet speed of 10 Mbps for HD streaming and 25 Mbps for 4K/Ultra HD content. Our adaptive streaming technology will adjust quality based on your connection to minimize buffering, but higher speeds will provide a better viewing experience.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Why am I experiencing buffering?</h3>
              <p className="text-gray-600">
                Buffering can occur due to several factors: slow internet connection, network congestion, Wi-Fi interference, or device limitations. Try these troubleshooting steps: check your internet speed, use a wired connection instead of Wi-Fi if possible, close other applications using bandwidth, restart your device, or lower the streaming quality in settings.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">How do I set up StreamFlex IPTV on my device?</h3>
              <p className="text-gray-600">
                Setting up is simple: 1) Download the StreamFlex IPTV app from your device's app store or access our web player, 2) Sign in with your account credentials, 3) Start watching! We provide detailed setup guides for all supported devices in our Help Center, and our customer support team is available 24/7 to assist with any setup issues.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Can I use a VPN with StreamFlex IPTV?</h3>
              <p className="text-gray-600">
                Yes, StreamFlex IPTV works with most VPN services. However, using a VPN might affect your streaming quality due to the additional encryption and routing. If you experience issues while using a VPN, try connecting to a server closer to your actual location or temporarily disabling the VPN to see if performance improves.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Subscription & Billing */}
      <section id="subscription" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Subscription & Billing</h2>
          
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">What subscription plans do you offer?</h3>
              <p className="text-gray-600">
                We offer three flexible subscription plans: Monthly ($15.99/month for 1 device), Quarterly ($39.99/3 months for 2 devices), and Annual ($119.99/year for 4 devices). All plans include full access to our entire channel lineup and on-demand library. The longer-term plans offer significant savings and support for multiple simultaneous devices.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">How does the free trial work?</h3>
              <p className="text-gray-600">
                Our 3-day free trial gives you full access to all features and content. No credit card is required to start the trial. You'll receive login details immediately after signing up. After the trial period, you can choose to subscribe to one of our plans or your account will simply expire with no charges.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">What payment methods do you accept?</h3>
              <p className="text-gray-600">
                We accept all major credit cards (Visa, MasterCard, American Express, Discover), PayPal, Apple Pay, Google Pay, and cryptocurrency payments (Bitcoin, Ethereum). All transactions are secure and encrypted, and your payment information is never stored on our servers.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Can I cancel my subscription?</h3>
              <p className="text-gray-600">
                Yes, you can cancel your subscription at any time from your account dashboard. There are no cancellation fees or hidden charges. If you cancel, you'll continue to have access until the end of your current billing period. We also offer a 7-day money-back guarantee if you're not satisfied with our service.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Content & Channels */}
      <section id="content" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Content & Channels</h2>
          
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">What channels are included?</h3>
              <p className="text-gray-600">
                StreamFlex IPTV offers 20,000+ channels from around the world, including premium sports (ESPN, Fox Sports, NFL Network), entertainment (HBO, Showtime, Disney+), news (CNN, BBC, Fox News), and international channels from 100+ countries. You can view our complete channel lineup on our Channels page or contact support for specific channel availability.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Do you offer local channels?</h3>
              <p className="text-gray-600">
                Yes, we provide local channels for many regions worldwide. Our service includes local ABC, NBC, CBS, FOX, and other regional networks for most major markets. The specific local channels available depend on your location, which you can specify in your account settings.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">What on-demand content is available?</h3>
              <p className="text-gray-600">
                Our on-demand library features 60,000+ titles including the latest movies, complete TV series, documentaries, and children's programming. We regularly update our library with new releases and popular content. You can browse categories, search for specific titles, or use our recommendation system to discover new content.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Do you offer sports packages?</h3>
              <p className="text-gray-600">
                Yes, all our subscription plans include comprehensive sports coverage with channels like ESPN, Fox Sports, NBC Sports, NFL Network, NBA TV, MLB Network, and international sports networks. We also provide access to pay-per-view events and regional sports networks for local team coverage.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Devices & Compatibility */}
      <section id="devices" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold mb-8 text-center">Devices & Compatibility</h2>
          
          <div className="max-w-3xl mx-auto space-y-8">
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">What devices can I use with StreamFlex IPTV?</h3>
              <p className="text-gray-600">
                StreamFlex IPTV is compatible with a wide range of devices: Smart TVs (Samsung, LG, Android TV), streaming devices (Roku, Amazon Fire TV, Apple TV, Chromecast), mobile devices (iOS and Android smartphones and tablets), and computers (Windows, Mac, Linux via web browser). Our apps are available in the respective app stores for each platform.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">How many devices can I use simultaneously?</h3>
              <p className="text-gray-600">
                The number of simultaneous devices depends on your subscription plan: Monthly plan supports 1 device, Quarterly plan supports 2 devices, and Annual plan supports 4 devices at the same time. You can manage your connected devices through your account dashboard.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Can I watch on my mobile device?</h3>
              <p className="text-gray-600">
                Yes, our mobile apps for iOS and Android provide the full StreamFlex IPTV experience on your smartphone or tablet. You can watch live TV, access on-demand content, record programs, and manage your account. The apps also support downloading content for offline viewing when you don't have an internet connection.
              </p>
            </div>
            
            <div className="bg-gray-50 p-6 rounded-lg shadow-sm">
              <h3 className="text-xl font-semibold mb-3">Is StreamFlex IPTV compatible with older devices?</h3>
              <p className="text-gray-600">
                Our service works best with devices manufactured within the last 5-7 years. For older devices, functionality may be limited or performance may be affected. We recommend using devices with at least 1GB of RAM and running recent operating system versions for the best experience.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Still Have Questions */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Our support team is available 24/7 to help you with any questions or issues you might have.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link href="/contact">
              <Button className="bg-white text-blue-600 hover:bg-gray-100 text-lg py-6 px-8">
                Contact Support
              </Button>
            </Link>
            <Link href="/subscribe">
              <Button variant="outline" className="border-white text-white hover:bg-blue-700 text-lg py-6 px-8">
                Start Free Trial
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
