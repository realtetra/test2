import Link from "next/link";
import { Button } from "@/components/ui/button";

export default function Header() {
  return (
    <header className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold text-blue-500">
              StreamFlex<span className="text-red-500">IPTV</span>
            </Link>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <Link href="/features" className="hover:text-blue-400 transition-colors">
              Features
            </Link>
            <Link href="/channels" className="hover:text-blue-400 transition-colors">
              Channels
            </Link>
            <Link href="/pricing" className="hover:text-blue-400 transition-colors">
              Pricing
            </Link>
            <Link href="/support" className="hover:text-blue-400 transition-colors">
              Support
            </Link>
          </nav>
          
          <div className="flex items-center space-x-4">
            <Link href="/login" className="hover:text-blue-400 transition-colors hidden md:inline">
              Login
            </Link>
            <Button className="bg-blue-600 hover:bg-blue-700">
              Get Started
            </Button>
            
            <button className="md:hidden">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
