# IPTV Website Deployment Instructions

This document provides instructions for deploying the StreamFlex IPTV website.

## Project Overview

The StreamFlex IPTV website is built using Next.js and Tailwind CSS. It includes:

- Responsive design for all devices
- Complete pages: Home, Features, Pricing, Channels, Subscribe, Contact, and FAQ
- Subscription form with validation
- Contact form
- Modern UI with professional styling

## Deployment Options

### Option 1: Deploy with Vercel (Recommended)

1. Create an account on [Vercel](https://vercel.com/) if you don't have one
2. Install Vercel CLI: `npm install -g vercel`
3. Navigate to the project directory: `cd iptv-website`
4. Run: `vercel login`
5. Deploy with: `vercel`
6. Follow the prompts to complete deployment

### Option 2: Deploy as Static Site

1. Modify the Next.js configuration:
   - Ensure `next.config.js` contains:
     ```js
     /** @type {import('next').NextConfig} */
     const nextConfig = {
       output: 'export',
       images: {
         unoptimized: true,
       },
     };
     
     module.exports = nextConfig;
     ```

2. Disable ESLint for build:
   - Create or modify `.eslintrc.json` with:
     ```json
     {
       "extends": "next/core-web-vitals",
       "rules": {
         "react/no-unescaped-entities": "off",
         "@typescript-eslint/no-unused-vars": "off"
       }
     }
     ```

3. Build the project:
   - Run: `npm run build`
   - This will create a static export in the `out` directory

4. Deploy the `out` directory to any static hosting service:
   - Netlify
   - GitHub Pages
   - Amazon S3
   - Firebase Hosting

### Option 3: Run Locally

1. Install dependencies: `npm install`
2. Start development server: `npm run dev`
3. Access the site at: http://localhost:3000

## Notes on ESLint Warnings

You may encounter ESLint warnings about unescaped entities and unused variables during the build process. These warnings don't affect the website's functionality but should be addressed for production deployment:

- Unescaped entities: Replace quotes and apostrophes with their HTML entity equivalents
- Unused variables: Remove or use the imported components

## Customization

- Update branding: Modify the company name "StreamFlex IPTV" in the code
- Replace images: Add your own images to the `public/images` directory
- Update pricing: Modify the pricing information in `src/app/pricing/page.tsx`
- Add your own channel lineup: Update the channel information in `src/app/channels/page.tsx`

## Support

For any questions or issues with deployment, please contact your developer or refer to the [Next.js documentation](https://nextjs.org/docs/deployment).
